Informações sobre o código do grupo 5:
Edson Lucas
Jheickson Felipe
Luydi Matheu

Primeiramente certifique-se de ter o JDK (Java Development Kit) instalado em seu computador.

Se estiver utilizando uma IDE:
	Abra o arquivo "Parser.java" através da IDE.
	Pressionar o botão/atalho de execução (CTRL + F5 no VSCODE).
	
Através do terminal/cmd:
	Navegue até o diretório onde o arquivo está salvo.
	Compile o arquivo com "javac Parser.java". Isso irá gerar um arquivo ".class".
	Execute o arquivo criado durante a compilação.
	
O código possui 5 inputs exemplo.
Espaços são ignorados.
A cada token/ID/Digito consumido é imprimido um aviso no terminal.
Um input é aceito quando o seu último caractere é consumido.
Um input é recusado quando ocorre algum erro, o qual será detalhado no terminal através de uma mensagem.