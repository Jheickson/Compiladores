package inter.stmt;

import inter.Node;

public abstract class Stmt extends Node {
	public abstract void gen();
}
